import axios from 'axios';

const API_URL = '/api/ai';

const getAuthHeader = () => {
  const token = localStorage.getItem('token');
  return token ? { headers: { 'x-auth-token': token } } : {};
};

const getAnalysis = (ticker) => {
  return axios.post(`${API_URL}/analyze`, { ticker }, getAuthHeader());
};

const aiService = {
  getAnalysis,
};

export default aiService;
