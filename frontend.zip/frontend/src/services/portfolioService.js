import axios from 'axios';

const API_URL = '/api/portfolio';

const getAuthHeader = () => {
  const token = localStorage.getItem('token');
  if (token) {
    return { headers: { 'x-auth-token': token } };
  } else {
    return {};
  }
};


const getHoldings = () => {
  return axios.get(API_URL, getAuthHeader());
};

const addHolding = (holdingData) => {
  return axios.post(API_URL, holdingData, getAuthHeader());
};

const deleteHolding = (id) => {
  return axios.delete(`${API_URL}/${id}`, getAuthHeader());
};


const updateHolding = (id, holdingData) => {
  return axios.put(`${API_URL}/${id}`, holdingData, getAuthHeader());
};
const portfolioService = {
  getHoldings,
  addHolding,
  deleteHolding,
  updateHolding,
};

export default portfolioService;
