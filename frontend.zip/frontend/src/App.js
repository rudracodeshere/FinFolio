import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Register from './pages/Register';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Portfolio from './pages/Portfolio';
import ChartPage from './pages/ChartPage';
function App() {
  return (
    <AuthProvider>
      <Router>

        <Navbar />

        <main className="bg-slate-50 min-h-screen">
          <Routes>
            <Route path="/register" element={<Register />} />
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/portfolio" element={<Portfolio />} />
            <Route path="/chart/:ticker" element={<ChartPage />} />
          </Routes>
        </main>
      </Router>
    </AuthProvider>
  );
}

export default App;
